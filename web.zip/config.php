<?php 
// error_reporting(0);
include "baseurl.php";
include 'database/connect.php';
include 'global_function.php';
// $result = fetchData('multiple','SELECT * FROM tbl_user');
// var_dump($result);
?>